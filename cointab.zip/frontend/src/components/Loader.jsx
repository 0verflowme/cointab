import Spinner from 'react-bootstrap/Spinner';

function Loader() {
  return <Spinner className='ms-5' animation="grow" />;
}

export default Loader;